from docx import Document
from openpyxl import load_workbook

# Đường dẫn đến file mẫu Word và file Excel
template_path = 'template.docx'
data_path = 'data.xlsx'

# Tải dữ liệu từ file Excel
wb = load_workbook(data_path)
ws = wb.active

# Lặp qua các hàng trong file Excel và tạo giấy mời
for row in ws.iter_rows(min_row=2, values_only=True):
    ho_ten,email, ten_su_kien, ngay, dia_diem = row

    # Đọc nội dung từ file mẫu Word
    doc = Document(template_path)
    for paragraph in doc.paragraphs:
        if '[Họ tên]' in paragraph.text:
            paragraph.text = paragraph.text.replace('[Họ tên]', ho_ten)
        if '[Tên sự kiện]' in paragraph.text:
            paragraph.text = paragraph.text.replace('[Tên sự kiện]', ten_su_kien)
        if '[Ngày]' in paragraph.text:
            ngay_str = ngay.strftime("%d/%m/%Y")
            paragraph.text = paragraph.text.replace('[Ngày]', ngay_str)

        if '[Địa điểm]' in paragraph.text:
            paragraph.text = paragraph.text.replace('[Địa điểm]', dia_diem)

    # Lưu thư mời với tên tệp động
    #file_name = f"Giay_moi_{email}.docx"
    file_name = f"{email}.docx"
    doc.save(f".\emai_to\{file_name}")
